"use client";

import { useEffect, useState, useCallback } from "react";
import { createClient } from "@/lib/supabaseClient";

export default function BannedWordsPage() {
  const supabase = createClient();
  const [isAdmin, setIsAdmin] = useState(null);
  const [words, setWords] = useState([]);
  const [newWord, setNewWord] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setIsAdmin(false);
      setLoading(false);
      return;
    }
    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();
    setIsAdmin(profile?.role === "admin");

    if (profile?.role === "admin") {
      const { data } = await supabase
        .from("banned_words")
        .select("id, word")
        .order("word", { ascending: true });
      setWords(data || []);
    }
    setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function addWord(e) {
    e.preventDefault();
    setError("");
    const word = newWord.trim();
    if (!word) return;

    const { error } = await supabase.from("banned_words").insert({ word });
    if (error) {
      setError("이미 등록된 단어이거나 추가할 수 없어요.");
      return;
    }
    setNewWord("");
    load();
  }

  async function removeWord(id) {
    await supabase.from("banned_words").delete().eq("id", id);
    load();
  }

  if (loading) return <p className="max-w-2xl mx-auto px-6 py-20 text-dim">불러오는 중...</p>;
  if (!isAdmin) {
    return (
      <p className="max-w-2xl mx-auto px-6 py-20 text-dim text-sm">
        이 페이지는 관리자만 볼 수 있어요.
      </p>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-6 py-14">
      <p className="text-signal font-display text-sm mb-2">MODERATION</p>
      <h1 className="font-display font-700 text-3xl text-ink mb-2">금지어 관리</h1>
      <p className="text-dim text-sm mb-8">
        여기 등록된 단어가 하루 글에 포함되면 자동으로 경고가 부여돼요. 필요한 단어를
        자유롭게 추가하거나 삭제할 수 있습니다.
      </p>

      <form onSubmit={addWord} className="flex gap-2 mb-8">
        <input
          value={newWord}
          onChange={(e) => setNewWord(e.target.value)}
          placeholder="추가할 단어 입력"
          className="flex-1 bg-panel border border-line rounded px-3 py-2 text-ink focus:border-circuit outline-none"
        />
        <button
          type="submit"
          className="px-4 py-2 rounded bg-signal text-base text-sm font-display font-700"
        >
          추가
        </button>
      </form>
      {error && <p className="text-signal text-xs -mt-6 mb-6">{error}</p>}

      {words.length === 0 ? (
        <p className="text-dim text-sm">등록된 금지어가 없어요.</p>
      ) : (
        <ul className="flex flex-wrap gap-2">
          {words.map((w) => (
            <li
              key={w.id}
              className="flex items-center gap-2 px-3 py-1.5 border border-line rounded-full text-sm text-ink bg-panel"
            >
              {w.word}
              <button
                onClick={() => removeWord(w.id)}
                className="text-dim hover:text-signal transition-colors"
                aria-label={`${w.word} 삭제`}
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
