"use client";

import { useEffect, useState, useCallback } from "react";
import { createClient } from "@/lib/supabaseClient";

export default function AdminRequestsPage() {
  const supabase = createClient();
  const [isAdmin, setIsAdmin] = useState(null);
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setIsAdmin(false);
      setLoading(false);
      return;
    }
    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();
    setIsAdmin(profile?.role === "admin");

    if (profile?.role === "admin") {
      const { data } = await supabase
        .from("admin_requests")
        .select("id, message, status, created_at, user_id, profiles:user_id (nickname)")
        .order("created_at", { ascending: false });
      setRequests(data || []);
    }
    setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function decide(req, approve) {
    const ok = confirm(
      `${req.profiles?.nickname ?? "이 사용자"}에게 관리자 권한을 허용하시겠습니까?`
    );
    if (approve && !ok) return;

    await supabase
      .from("admin_requests")
      .update({ status: approve ? "approved" : "rejected", decided_at: new Date().toISOString() })
      .eq("id", req.id);

    if (approve) {
      await supabase.from("profiles").update({ role: "admin" }).eq("id", req.user_id);
    }
    load();
  }

  if (loading) return <p className="max-w-2xl mx-auto px-6 py-20 text-dim">불러오는 중...</p>;
  if (!isAdmin) {
    return (
      <p className="max-w-2xl mx-auto px-6 py-20 text-dim text-sm">
        이 페이지는 관리자만 볼 수 있어요.
      </p>
    );
  }

  const pending = requests.filter((r) => r.status === "pending");
  const decided = requests.filter((r) => r.status !== "pending");

  return (
    <div className="max-w-2xl mx-auto px-6 py-14">
      <p className="text-signal font-display text-sm mb-2">ADMIN ACCESS</p>
      <h1 className="font-display font-700 text-3xl text-ink mb-8">관리자 권한 신청 관리</h1>

      <h2 className="text-sm text-dim mb-3">대기 중인 신청 ({pending.length})</h2>
      {pending.length === 0 ? (
        <p className="text-dim text-sm mb-10">대기 중인 신청이 없어요.</p>
      ) : (
        <ul className="space-y-3 mb-10">
          {pending.map((r) => (
            <li key={r.id} className="p-4 border border-signal/40 rounded-lg bg-panel">
              <p className="text-ink font-display">{r.profiles?.nickname}</p>
              {r.message && <p className="mt-1 text-sm text-dim">{r.message}</p>}
              <p className="mt-1 text-[11px] text-dim/70">
                {new Date(r.created_at).toLocaleString("ko-KR")}
              </p>
              <div className="mt-3 flex gap-2">
                <button
                  onClick={() => decide(r, true)}
                  className="px-3 py-1.5 rounded bg-circuit text-base text-xs font-display font-700"
                >
                  허용
                </button>
                <button
                  onClick={() => decide(r, false)}
                  className="px-3 py-1.5 rounded border border-line text-dim text-xs"
                >
                  거절
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <h2 className="text-sm text-dim mb-3">처리된 신청</h2>
      {decided.length === 0 ? (
        <p className="text-dim text-sm">아직 없어요.</p>
      ) : (
        <ul className="space-y-2">
          {decided.map((r) => (
            <li key={r.id} className="text-sm text-dim flex justify-between border-b border-line py-2">
              <span>{r.profiles?.nickname}</span>
              <span className={r.status === "approved" ? "text-circuit" : "text-signal"}>
                {r.status === "approved" ? "승인됨" : "거절됨"}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
