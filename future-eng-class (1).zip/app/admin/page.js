"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabaseClient";

export default function AdminDashboard() {
  const supabase = createClient();
  const [isAdmin, setIsAdmin] = useState(null);
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pendingCount, setPendingCount] = useState(0);

  const load = useCallback(async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setIsAdmin(false);
      setLoading(false);
      return;
    }
    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();
    setIsAdmin(profile?.role === "admin");

    if (profile?.role === "admin") {
      const { data } = await supabase
        .from("profiles")
        .select("id, nickname, role, status, warning_count")
        .order("warning_count", { ascending: false });
      setMembers(data || []);

      const { count } = await supabase
        .from("admin_requests")
        .select("id", { count: "exact", head: true })
        .eq("status", "pending");
      setPendingCount(count || 0);
    }
    setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function unban(id) {
    await supabase
      .from("profiles")
      .update({ status: "active", warning_count: 0 })
      .eq("id", id);
    load();
  }

  async function resetWarnings(id) {
    await supabase.from("profiles").update({ warning_count: 0 }).eq("id", id);
    load();
  }

  if (loading) return <p className="max-w-4xl mx-auto px-6 py-20 text-dim">불러오는 중...</p>;
  if (!isAdmin) {
    return (
      <p className="max-w-4xl mx-auto px-6 py-20 text-dim text-sm">
        이 페이지는 관리자만 볼 수 있어요.
      </p>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-14">
      <p className="text-signal font-display text-sm mb-2">ADMIN</p>
      <h1 className="font-display font-700 text-3xl text-ink mb-8">관리자 대시보드</h1>

      <div className="grid sm:grid-cols-3 gap-4 mb-12">
        <Link
          href="/admin/requests"
          className="p-5 border border-line rounded-lg bg-panel hover:border-signal transition-colors"
        >
          <p className="text-sm text-dim">관리자 권한 신청</p>
          <p className="mt-1 font-display text-2xl text-ink">{pendingCount}건 대기</p>
        </Link>
        <Link
          href="/class-intro"
          className="p-5 border border-line rounded-lg bg-panel hover:border-circuit transition-colors"
        >
          <p className="text-sm text-dim">학급 소개 편집</p>
          <p className="mt-1 font-display text-lg text-ink">연도 · 학생 · 선생님 관리</p>
        </Link>
        <Link
          href="/news"
          className="p-5 border border-line rounded-lg bg-panel hover:border-circuit transition-colors"
        >
          <p className="text-sm text-dim">소식 누리집 편집</p>
          <p className="mt-1 font-display text-lg text-ink">공지 · 소식 작성/수정</p>
        </Link>
        <Link
          href="/admin/words"
          className="p-5 border border-line rounded-lg bg-panel hover:border-signal transition-colors"
        >
          <p className="text-sm text-dim">금지어 관리</p>
          <p className="mt-1 font-display text-lg text-ink">하루 글 자동 경고 단어 추가/삭제</p>
        </Link>
      </div>

      <h2 className="font-display text-xl text-ink mb-4">회원 · 경고 관리</h2>
      <div className="border border-line rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-panel text-dim text-left">
              <th className="px-4 py-3 font-normal">닉네임</th>
              <th className="px-4 py-3 font-normal">권한</th>
              <th className="px-4 py-3 font-normal">경고</th>
              <th className="px-4 py-3 font-normal">상태</th>
              <th className="px-4 py-3 font-normal">조치</th>
            </tr>
          </thead>
          <tbody>
            {members.map((m) => (
              <tr key={m.id} className="border-t border-line">
                <td className="px-4 py-3 text-ink">{m.nickname}</td>
                <td className="px-4 py-3 text-dim">{m.role === "admin" ? "관리자" : "구성원"}</td>
                <td className={`px-4 py-3 ${m.warning_count > 0 ? "text-signal" : "text-dim"}`}>
                  {m.warning_count} / 3
                </td>
                <td className="px-4 py-3">
                  {m.status === "banned" ? (
                    <span className="text-signal">이용 제한</span>
                  ) : (
                    <span className="text-circuit">정상</span>
                  )}
                </td>
                <td className="px-4 py-3 space-x-3">
                  {m.status === "banned" && (
                    <button
                      onClick={() => unban(m.id)}
                      className="text-circuit hover:underline"
                    >
                      제한 해제
                    </button>
                  )}
                  {m.warning_count > 0 && m.status !== "banned" && (
                    <button
                      onClick={() => resetWarnings(m.id)}
                      className="text-dim hover:text-ink hover:underline"
                    >
                      경고 초기화
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
