"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabaseClient";

export default function AdminRequestPage() {
  const supabase = createClient();
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState(null); // 최근 신청 상태
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function init() {
      const {
        data: { user: u },
      } = await supabase.auth.getUser();
      setUser(u || null);
      if (u) {
        const { data } = await supabase
          .from("admin_requests")
          .select("status, created_at")
          .eq("user_id", u.id)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        setStatus(data);
      }
      setLoading(false);
    }
    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function submit(e) {
    e.preventDefault();
    if (!user) return;
    await supabase.from("admin_requests").insert({ user_id: user.id, message });
    setSent(true);
  }

  if (loading) return <p className="max-w-md mx-auto px-6 py-20 text-dim">불러오는 중...</p>;

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <p className="text-dim text-sm">관리자 권한을 신청하려면 먼저 로그인해 주세요.</p>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto px-6 py-20">
      <p className="text-signal font-display text-sm mb-2">ADMIN ACCESS</p>
      <h1 className="font-display font-700 text-2xl text-ink mb-2">관리자 권한 신청</h1>
      <p className="text-dim text-sm mb-8">
        신청을 보내면 현재 관리자가 확인 후 이 링크의 요청에 대해 &quot;관리자 권한을
        허용하시겠습니까?&quot;라는 화면에서 승인 또는 거절할 수 있어요. 승인되면 관리자 기능이
        열리고, 거절되면 지금처럼 글 작성만 가능해요.
      </p>

      {status?.status === "pending" && !sent ? (
        <p className="text-sm text-circuit">이미 신청이 접수되어 검토 중이에요.</p>
      ) : status?.status === "approved" ? (
        <p className="text-sm text-circuit">이미 관리자 권한이 승인되었어요.</p>
      ) : sent ? (
        <p className="text-sm text-circuit">신청이 접수되었어요. 관리자의 승인을 기다려 주세요.</p>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="신청 사유를 간단히 남겨주세요 (선택)"
            rows={4}
            className="w-full bg-panel border border-line rounded px-3 py-2 text-ink focus:border-circuit outline-none"
          />
          <button
            type="submit"
            className="w-full py-2.5 rounded bg-signal text-base font-display font-700"
          >
            관리자 권한 신청하기
          </button>
        </form>
      )}
    </div>
  );
}
