import DailyBoard from "@/components/DailyBoard";

export default function DailyPage() {
  return (
    <div className="max-w-2xl mx-auto px-6 py-14">
      <p className="text-circuit font-display text-sm mb-2">DAILY</p>
      <h1 className="font-display font-700 text-3xl text-ink mb-2">하루 글</h1>
      <p className="text-dim text-sm mb-10">
        미래공학 반이라면 누구나 오늘의 한마디를 남길 수 있어요.
      </p>
      <DailyBoard />
    </div>
  );
}
