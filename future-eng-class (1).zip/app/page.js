import Hero from "@/components/Hero";
import NavCards from "@/components/NavCards";

export default function HomePage() {
  return (
    <>
      <Hero />
      <NavCards />
    </>
  );
}
