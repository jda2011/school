import { Space_Grotesk, Inter } from "next/font/google";
import "./globals.css";
import NavBar from "@/components/NavBar";

const display = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["500", "700"],
});
const body = Inter({
  subsets: ["latin"],
  variable: "--font-body",
});

export const metadata = {
  title: "미래공학 학급 홈페이지",
  description: "미래공학 반 아이들과 선생님들이 함께 만들어가는 기록 공간",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ko" className={`${display.variable} ${body.variable}`}>
      <body className="font-body min-h-screen flex flex-col">
        <NavBar />
        <main className="flex-1">{children}</main>
        <footer className="border-t border-line py-8 text-center text-sm text-dim">
          미래공학 학급 홈페이지 · 함께 기록하는 우리의 시간
        </footer>
      </body>
    </html>
  );
}
