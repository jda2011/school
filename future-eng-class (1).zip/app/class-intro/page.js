"use client";

import { useEffect, useState, useCallback } from "react";
import { createClient } from "@/lib/supabaseClient";
import YearSection from "@/components/YearSection";
import TeacherGrid from "@/components/TeacherGrid";

export default function ClassIntroPage() {
  const supabase = createClient();
  const [years, setYears] = useState([]);
  const [membersByYear, setMembersByYear] = useState({});
  const [teachers, setTeachers] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newYear, setNewYear] = useState("");
  const [yearError, setYearError] = useState("");

  const loadAll = useCallback(async () => {
    const { data: yearsData } = await supabase
      .from("class_years")
      .select("id, year")
      .order("year", { ascending: false });
    setYears(yearsData || []);

    const { data: membersData } = await supabase
      .from("members")
      .select("id, year_id, name, photo_url")
      .order("sort_order", { ascending: true });

    const grouped = {};
    (membersData || []).forEach((m) => {
      grouped[m.year_id] = grouped[m.year_id] || [];
      grouped[m.year_id].push(m);
    });
    setMembersByYear(grouped);

    const { data: teachersData } = await supabase
      .from("teachers")
      .select("id, name, photo_url")
      .order("sort_order", { ascending: true });
    setTeachers(teachersData || []);

    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user) {
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();
      setIsAdmin(profile?.role === "admin");
    } else {
      setIsAdmin(false);
    }
    setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  async function addYear(e) {
    e.preventDefault();
    setYearError("");
    const y = parseInt(newYear, 10);
    if (!y || y < 2028) {
      setYearError("2028년 이후의 연도만 직접 추가할 수 있어요.");
      return;
    }
    const { error } = await supabase
      .from("class_years")
      .insert({ year: y, is_custom: true });
    if (error) {
      setYearError("이미 있는 연도이거나 추가할 수 없습니다.");
      return;
    }
    setNewYear("");
    loadAll();
  }

  if (loading) {
    return <div className="max-w-6xl mx-auto px-6 py-16 text-dim">불러오는 중...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto px-6 py-14">
      <p className="text-circuit font-display text-sm mb-2">MEMBERS</p>
      <h1 className="font-display font-700 text-3xl text-ink mb-2">학급 소개</h1>
      <p className="text-dim text-sm mb-10">
        2005년부터 이어져 온 미래공학 반 구성원들을 연도별로 소개합니다.
      </p>

      {isAdmin && (
        <form onSubmit={addYear} className="mb-10 flex items-end gap-3">
          <div>
            <label className="block text-xs text-dim mb-1">새 연도 추가 (2028년 이후)</label>
            <input
              type="number"
              min={2028}
              value={newYear}
              onChange={(e) => setNewYear(e.target.value)}
              placeholder="예) 2028"
              className="bg-panel border border-line rounded px-3 py-2 text-ink w-40 focus:border-circuit outline-none"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 rounded bg-circuit text-base text-sm font-display font-700"
          >
            연도 창 만들기
          </button>
          {yearError && <p className="text-signal text-xs mb-2">{yearError}</p>}
        </form>
      )}

      <div>
        {years.map((y) => (
          <YearSection
            key={y.id}
            year={y.year}
            yearId={y.id}
            members={membersByYear[y.id] || []}
            isAdmin={isAdmin}
            onChange={loadAll}
          />
        ))}
      </div>

      <TeacherGrid teachers={teachers} isAdmin={isAdmin} onChange={loadAll} />
    </div>
  );
}
