import { NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabaseServer";

async function requireAdmin(supabase) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;
  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();
  return profile?.role === "admin" ? user : null;
}

// 관리자가 특정 하루글을 "신고 처리"하면 작성자에게 경고 1회를 부여하고 글을 삭제합니다.
export async function POST(request, { params }) {
  const supabase = createServerSupabase();
  const admin = await requireAdmin(supabase);
  if (!admin) {
    return NextResponse.json({ error: "권한이 없습니다." }, { status: 403 });
  }

  const { data: post } = await supabase
    .from("daily_posts")
    .select("id, author_id")
    .eq("id", params.id)
    .single();

  if (!post) {
    return NextResponse.json({ error: "글을 찾을 수 없습니다." }, { status: 404 });
  }

  const { data: authorProfile } = await supabase
    .from("profiles")
    .select("warning_count")
    .eq("id", post.author_id)
    .single();

  const newCount = (authorProfile?.warning_count || 0) + 1;
  const banned = newCount >= 3;

  await supabase
    .from("profiles")
    .update({ warning_count: newCount, status: banned ? "banned" : "active" })
    .eq("id", post.author_id);

  await supabase.from("daily_posts").delete().eq("id", params.id);

  return NextResponse.json({ ok: true, warningCount: newCount, banned });
}

export async function DELETE(request, { params }) {
  const supabase = createServerSupabase();
  const admin = await requireAdmin(supabase);
  if (!admin) {
    return NextResponse.json({ error: "권한이 없습니다." }, { status: 403 });
  }
  await supabase.from("daily_posts").delete().eq("id", params.id);
  return NextResponse.json({ ok: true });
}
