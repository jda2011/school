import { NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabaseServer";
import { checkContent } from "@/lib/badwords";

export async function POST(request) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "로그인이 필요합니다." }, { status: 401 });
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("nickname, status, warning_count")
    .eq("id", user.id)
    .single();

  if (!profile || profile.status === "banned") {
    return NextResponse.json(
      { error: "경고 누적으로 이용이 제한되었습니다." },
      { status: 403 }
    );
  }

  const { content } = await request.json();
  if (!content || !content.trim()) {
    return NextResponse.json({ error: "내용을 입력해 주세요." }, { status: 400 });
  }

  const { data: wordRows } = await supabase.from("banned_words").select("word");
  const bannedWords = (wordRows || []).map((w) => w.word);
  const { flagged, reason } = checkContent(content, bannedWords);

  const { error: insertError } = await supabase.from("daily_posts").insert({
    author_id: user.id,
    author_nickname: profile.nickname,
    content,
    is_flagged: flagged,
    flag_reason: reason,
  });

  if (insertError) {
    return NextResponse.json({ error: "글 등록에 실패했습니다." }, { status: 500 });
  }

  if (!flagged) {
    return NextResponse.json({ ok: true, flagged: false });
  }

  const newCount = (profile.warning_count || 0) + 1;
  const banned = newCount >= 3;

  await supabase
    .from("profiles")
    .update({
      warning_count: newCount,
      status: banned ? "banned" : "active",
    })
    .eq("id", user.id);

  return NextResponse.json({
    ok: true,
    flagged: true,
    warningCount: newCount,
    banned,
  });
}
