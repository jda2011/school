"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabaseClient";

export default function LoginPage() {
  const [mode, setMode] = useState("signin"); // "signin" | "signup"
  const [nickname, setNickname] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setMessage("");
    setLoading(true);

    if (mode === "signup") {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { nickname } },
      });
      if (error) {
        setError(error.message);
      } else {
        setMessage("가입되었습니다. 이제 로그인해 주세요.");
        setMode("signin");
      }
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        setError("이메일 또는 비밀번호가 올바르지 않아요.");
      } else {
        router.push("/");
        router.refresh();
      }
    }
    setLoading(false);
  }

  return (
    <div className="max-w-sm mx-auto px-6 py-20">
      <h1 className="font-display font-700 text-2xl text-ink mb-1">
        {mode === "signin" ? "로그인" : "회원가입"}
      </h1>
      <p className="text-sm text-dim mb-8">
        {mode === "signin"
          ? "하루 글 작성과 관리자 신청을 하려면 로그인하세요."
          : "닉네임과 이메일로 미래공학 반 계정을 만들어요."}
      </p>

      <form onSubmit={handleSubmit} className="space-y-4">
        {mode === "signup" && (
          <div>
            <label className="block text-xs text-dim mb-1">닉네임</label>
            <input
              required
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              className="w-full bg-panel border border-line rounded px-3 py-2 text-ink focus:border-circuit outline-none"
              placeholder="예) 미래공학 3기 홍길동"
            />
          </div>
        )}
        <div>
          <label className="block text-xs text-dim mb-1">이메일</label>
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-panel border border-line rounded px-3 py-2 text-ink focus:border-circuit outline-none"
          />
        </div>
        <div>
          <label className="block text-xs text-dim mb-1">비밀번호</label>
          <input
            required
            type="password"
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-panel border border-line rounded px-3 py-2 text-ink focus:border-circuit outline-none"
          />
        </div>

        {error && <p className="text-sm text-signal">{error}</p>}
        {message && <p className="text-sm text-circuit">{message}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2.5 rounded bg-circuit text-base font-display font-700 hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          {loading ? "처리 중..." : mode === "signin" ? "로그인" : "가입하기"}
        </button>
      </form>

      <button
        onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
        className="mt-6 text-sm text-dim hover:text-circuit transition-colors"
      >
        {mode === "signin" ? "계정이 없나요? 회원가입" : "이미 계정이 있나요? 로그인"}
      </button>
    </div>
  );
}
