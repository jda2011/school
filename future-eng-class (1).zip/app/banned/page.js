export default function BannedPage() {
  return (
    <div className="max-w-md mx-auto px-6 py-24 text-center">
      <p className="text-signal font-display text-sm mb-3">ACCESS SUSPENDED</p>
      <h1 className="font-display font-700 text-2xl text-ink mb-4">
        이용이 잠시 제한되었습니다
      </h1>
      <p className="text-dim text-sm leading-relaxed">
        하루 글에서 경고가 3회 누적되어 홈페이지 이용이 제한되었습니다.
        <br />
        관리자가 다시 허용하면 이용할 수 있습니다.
      </p>
    </div>
  );
}
