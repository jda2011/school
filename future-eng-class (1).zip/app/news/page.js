"use client";

import { useState } from "react";
import AdminBoard from "@/components/AdminBoard";

const TABS = [
  { key: "notices", table: "notices", label: "공지사항", tag: "공지" },
  { key: "news_posts", table: "news_posts", label: "소식 게시판", tag: "소식" },
];

export default function NewsPage() {
  const [active, setActive] = useState(TABS[0].key);
  const current = TABS.find((t) => t.key === active);

  return (
    <div className="max-w-3xl mx-auto px-6 py-14">
      <p className="text-circuit font-display text-sm mb-2">NOTICE</p>
      <h1 className="font-display font-700 text-3xl text-ink mb-8">소식 누리집</h1>

      <div className="flex gap-2 mb-8 border-b border-line">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setActive(t.key)}
            className={`px-4 py-2.5 text-sm -mb-px border-b-2 transition-colors ${
              active === t.key
                ? "border-circuit text-circuit"
                : "border-transparent text-dim hover:text-ink"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <AdminBoard table={current.table} title={current.label} tag={current.tag} />
    </div>
  );
}
