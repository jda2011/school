"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabaseClient";
import PhotoUploadSlot from "./PhotoUploadSlot";

export default function YearSection({ year, yearId, members, isAdmin, onChange }) {
  const supabase = createClient();
  const [adding, setAdding] = useState(false);

  async function addSlot() {
    setAdding(true);
    await supabase.from("members").insert({
      year_id: yearId,
      name: "",
      sort_order: members.length,
    });
    onChange?.();
    setAdding(false);
  }

  async function updateName(memberId, name) {
    await supabase.from("members").update({ name }).eq("id", memberId);
    onChange?.();
  }

  async function updatePhoto(memberId, url) {
    await supabase.from("members").update({ photo_url: url }).eq("id", memberId);
    onChange?.();
  }

  async function removeMember(memberId) {
    await supabase.from("members").delete().eq("id", memberId);
    onChange?.();
  }

  return (
    <section className="py-10 border-b border-line">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-display font-700 text-xl text-ink">{year}</h3>
        {isAdmin && (
          <button
            onClick={addSlot}
            disabled={adding}
            className="text-xs px-3 py-1.5 border border-line rounded text-dim hover:text-circuit hover:border-circuit transition-colors"
          >
            + 학생 추가
          </button>
        )}
      </div>

      {members.length === 0 ? (
        <p className="text-sm text-dim">아직 등록된 구성원이 없어요.</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-5">
          {members.map((m) => (
            <div key={m.id} className="text-center">
              <div className="aspect-square">
                <PhotoUploadSlot
                  photoUrl={m.photo_url}
                  storagePath={`members/${year}/${m.id}`}
                  editable={isAdmin}
                  onUploaded={(url) => updatePhoto(m.id, url)}
                />
              </div>
              {isAdmin ? (
                <input
                  defaultValue={m.name}
                  placeholder="이름"
                  onBlur={(e) => updateName(m.id, e.target.value)}
                  className="mt-2 w-full bg-transparent text-center text-sm text-ink border-b border-line focus:border-circuit outline-none"
                />
              ) : (
                <p className="mt-2 text-sm text-ink">{m.name || "이름 미정"}</p>
              )}
              {isAdmin && (
                <button
                  onClick={() => removeMember(m.id)}
                  className="mt-1 text-[11px] text-dim hover:text-signal transition-colors"
                >
                  삭제
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
