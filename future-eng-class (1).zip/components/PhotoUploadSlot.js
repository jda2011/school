"use client";

import { useRef, useState } from "react";
import Image from "next/image";
import { createClient } from "@/lib/supabaseClient";

// props:
// - photoUrl: 현재 사진 URL (없으면 placeholder)
// - storagePath: 업로드될 storage 경로 (예: `members/2010/3`)
// - editable: 관리자 모드에서만 true로 넘겨서 업로드 가능하게
// - onUploaded(url): 업로드 성공 시 호출
// - shape: "square" | "circle"
export default function PhotoUploadSlot({
  photoUrl,
  storagePath,
  editable = false,
  onUploaded,
  shape = "square",
}) {
  const inputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const supabase = createClient();

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError("");

    const ext = file.name.split(".").pop();
    const filePath = `${storagePath}-${Date.now()}.${ext}`;

    const { error: uploadError } = await supabase.storage
      .from("photos")
      .upload(filePath, file, { upsert: true });

    if (uploadError) {
      setError("업로드에 실패했어요. 다시 시도해 주세요.");
      setUploading(false);
      return;
    }

    const {
      data: { publicUrl },
    } = supabase.storage.from("photos").getPublicUrl(filePath);

    onUploaded?.(publicUrl);
    setUploading(false);
  }

  const roundedClass = shape === "circle" ? "rounded-full" : "rounded-md";

  return (
    <div
      className={`relative w-full h-full ${roundedClass} overflow-hidden border border-line bg-base/60 flex items-center justify-center`}
    >
      {photoUrl ? (
        <Image
          src={photoUrl}
          alt=""
          fill
          sizes="200px"
          className="object-cover"
        />
      ) : editable ? (
        <label className="cursor-pointer text-center px-3 text-xs text-dim hover:text-circuit transition-colors">
          {uploading ? "업로드 중..." : "사진을 넣어주세요"}
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFile}
          />
        </label>
      ) : (
        <span className="text-xs text-dim">사진 준비 중</span>
      )}

      {editable && photoUrl && (
        <label className="absolute inset-0 flex items-center justify-center bg-base/0 hover:bg-base/70 text-transparent hover:text-ink text-xs cursor-pointer transition-colors">
          사진 변경
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFile}
          />
        </label>
      )}

      {error && (
        <p className="absolute bottom-1 left-1 right-1 text-[10px] text-signal text-center">
          {error}
        </p>
      )}
    </div>
  );
}
