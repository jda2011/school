"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabaseClient";

const LINKS = [
  { href: "/class-intro", label: "학급 소개" },
  { href: "/news", label: "소식 누리집" },
  { href: "/daily", label: "하루 글" },
];

export default function NavBar() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const pathname = usePathname();
  const router = useRouter();
  const supabase = createClient();

  useEffect(() => {
    let mounted = true;

    async function load() {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        if (mounted) {
          setProfile(null);
          setLoading(false);
        }
        return;
      }
      const { data } = await supabase
        .from("profiles")
        .select("nickname, role, status")
        .eq("id", user.id)
        .single();
      if (mounted) {
        setProfile(data);
        setLoading(false);
      }
    }
    load();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(() => load());
    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/");
    router.refresh();
  }

  return (
    <header className="border-b border-line bg-panel/80 backdrop-blur sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link href="/" className="font-display font-700 text-lg tracking-tight text-ink">
          미래공학<span className="text-circuit">.</span>
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          {LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={`text-sm transition-colors ${
                pathname?.startsWith(l.href)
                  ? "text-circuit"
                  : "text-dim hover:text-ink"
              }`}
            >
              {l.label}
            </Link>
          ))}
          {profile?.role === "admin" && (
            <Link
              href="/admin"
              className={`text-sm transition-colors ${
                pathname?.startsWith("/admin") ? "text-signal" : "text-signal/80 hover:text-signal"
              }`}
            >
              관리자
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-4 text-sm">
          {loading ? null : profile ? (
            <>
              {profile.role !== "admin" && (
                <Link
                  href="/admin/request"
                  className="hidden sm:inline text-dim hover:text-signal transition-colors"
                >
                  관리자 신청
                </Link>
              )}
              <span className="text-dim hidden sm:inline">
                {profile.nickname}
                {profile.role === "admin" && (
                  <span className="ml-1 text-signal">(관리자)</span>
                )}
              </span>
              <button
                onClick={handleLogout}
                className="px-3 py-1.5 rounded border border-line text-dim hover:text-ink hover:border-circuit transition-colors"
              >
                로그아웃
              </button>
            </>
          ) : (
            <Link
              href="/login"
              className="px-3 py-1.5 rounded border border-circuit text-circuit hover:bg-circuit hover:text-base transition-colors"
            >
              로그인
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
