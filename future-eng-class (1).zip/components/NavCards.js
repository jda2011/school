import Link from "next/link";

const CARDS = [
  {
    href: "/class-intro",
    tag: "MEMBERS",
    title: "학급 소개",
    desc: "2005년부터 지금까지, 학년도별 구성원과 선생님들",
  },
  {
    href: "/news",
    tag: "NOTICE",
    title: "소식 누리집",
    desc: "공지사항과 소식 게시판",
  },
  {
    href: "/daily",
    tag: "DAILY",
    title: "하루 글",
    desc: "미래공학 반 누구나 남기는 오늘의 한마디",
  },
];

export default function NavCards() {
  return (
    <section className="max-w-6xl mx-auto px-6 py-16">
      <div className="grid sm:grid-cols-3 gap-px bg-line border border-line rounded-lg overflow-hidden">
        {CARDS.map((c) => (
          <Link
            key={c.href}
            href={c.href}
            className="group bg-panel p-7 hover:bg-base transition-colors"
          >
            <p className="text-xs text-circuit font-display tracking-wide">{c.tag}</p>
            <h2 className="mt-3 font-display font-700 text-xl text-ink">{c.title}</h2>
            <p className="mt-2 text-sm text-dim">{c.desc}</p>
            <p className="mt-5 text-sm text-circuit opacity-0 group-hover:opacity-100 transition-opacity">
              열어보기
            </p>
          </Link>
        ))}
      </div>
    </section>
  );
}
