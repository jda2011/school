"use client";

import { useEffect, useState, useCallback } from "react";
import { createClient } from "@/lib/supabaseClient";

// props: table = "notices" | "news_posts", title, tag
export default function AdminBoard({ table, title, tag }) {
  const supabase = createClient();
  const [posts, setPosts] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ title: "", content: "" });
  const [editingId, setEditingId] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    const { data } = await supabase
      .from(table)
      .select("id, title, content, created_at, updated_at")
      .order("created_at", { ascending: false });
    setPosts(data || []);

    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user) {
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();
      setIsAdmin(profile?.role === "admin");
    } else {
      setIsAdmin(false);
    }
    setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [table]);

  useEffect(() => {
    load();
  }, [load]);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.title.trim() || !form.content.trim()) return;
    setSaving(true);

    if (editingId) {
      await supabase
        .from(table)
        .update({ title: form.title, content: form.content, updated_at: new Date().toISOString() })
        .eq("id", editingId);
    } else {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      await supabase.from(table).insert({
        title: form.title,
        content: form.content,
        created_by: user?.id,
      });
    }

    setForm({ title: "", content: "" });
    setEditingId(null);
    setSaving(false);
    load();
  }

  function startEdit(post) {
    setEditingId(post.id);
    setForm({ title: post.title, content: post.content });
  }

  async function remove(id) {
    if (!confirm("이 글을 삭제할까요?")) return;
    await supabase.from(table).delete().eq("id", id);
    load();
  }

  if (loading) return <p className="text-dim text-sm">불러오는 중...</p>;

  return (
    <div>
      {isAdmin && (
        <form
          onSubmit={handleSubmit}
          className="mb-8 p-5 border border-line rounded-lg bg-panel space-y-3"
        >
          <p className="text-xs text-circuit font-display">
            {editingId ? "글 수정" : `${tag} 작성`}
          </p>
          <input
            required
            value={form.title}
            onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
            placeholder="제목"
            className="w-full bg-base border border-line rounded px-3 py-2 text-ink focus:border-circuit outline-none"
          />
          <textarea
            required
            value={form.content}
            onChange={(e) => setForm((f) => ({ ...f, content: e.target.value }))}
            placeholder="내용"
            rows={4}
            className="w-full bg-base border border-line rounded px-3 py-2 text-ink focus:border-circuit outline-none"
          />
          <div className="flex gap-2">
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 rounded bg-circuit text-base text-sm font-display font-700"
            >
              {editingId ? "수정 완료" : "등록"}
            </button>
            {editingId && (
              <button
                type="button"
                onClick={() => {
                  setEditingId(null);
                  setForm({ title: "", content: "" });
                }}
                className="px-4 py-2 rounded border border-line text-dim text-sm"
              >
                취소
              </button>
            )}
          </div>
        </form>
      )}

      {posts.length === 0 ? (
        <p className="text-dim text-sm">아직 등록된 글이 없어요.</p>
      ) : (
        <ul className="space-y-4">
          {posts.map((p) => (
            <li key={p.id} className="p-5 border border-line rounded-lg bg-panel">
              <div className="flex items-start justify-between gap-4">
                <h3 className="font-display font-700 text-ink">{p.title}</h3>
                {isAdmin && (
                  <div className="flex gap-2 shrink-0 text-xs">
                    <button
                      onClick={() => startEdit(p)}
                      className="text-dim hover:text-circuit transition-colors"
                    >
                      수정
                    </button>
                    <button
                      onClick={() => remove(p.id)}
                      className="text-dim hover:text-signal transition-colors"
                    >
                      삭제
                    </button>
                  </div>
                )}
              </div>
              <p className="mt-2 text-sm text-dim whitespace-pre-wrap">{p.content}</p>
              <p className="mt-3 text-[11px] text-dim/70">
                {new Date(p.created_at).toLocaleDateString("ko-KR")}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
