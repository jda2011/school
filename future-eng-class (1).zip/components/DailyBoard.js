"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabaseClient";

export default function DailyBoard() {
  const supabase = createClient();
  const [posts, setPosts] = useState([]);
  const [content, setContent] = useState("");
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);
  const [notice, setNotice] = useState("");

  const load = useCallback(async () => {
    const { data } = await supabase
      .from("daily_posts")
      .select("id, author_nickname, content, created_at, is_flagged")
      .order("created_at", { ascending: false })
      .limit(100);
    setPosts(data || []);

    const {
      data: { user: u },
    } = await supabase.auth.getUser();
    setUser(u || null);
    if (u) {
      const { data: p } = await supabase
        .from("profiles")
        .select("nickname, role, status, warning_count")
        .eq("id", u.id)
        .single();
      setProfile(p);
      setIsAdmin(p?.role === "admin");
    }
    setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!content.trim()) return;
    setPosting(true);
    setNotice("");

    const res = await fetch("/api/daily", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    });
    const result = await res.json();

    if (!res.ok) {
      setNotice(result.error || "글을 등록하지 못했어요.");
    } else if (result.flagged) {
      setNotice(
        `⚠ 부적절한 표현이 감지되어 경고가 부여되었습니다. (누적 경고 ${result.warningCount}/3)` +
          (result.banned ? " 경고 3회로 이용이 제한되었습니다." : "")
      );
    } else {
      setContent("");
    }
    setPosting(false);
    load();
  }

  async function reportPost(id) {
    if (!confirm("이 글의 작성자에게 경고를 부여하고 글을 삭제할까요?")) return;
    const res = await fetch(`/api/daily/${id}`, { method: "POST" });
    const result = await res.json();
    if (res.ok) {
      alert(
        `경고가 부여되었습니다. (누적 ${result.warningCount}/3)` +
          (result.banned ? " 경고 3회로 이용이 제한되었습니다." : "")
      );
      load();
    }
  }

  async function deletePost(id) {
    if (!confirm("이 글을 삭제할까요?")) return;
    await fetch(`/api/daily/${id}`, { method: "DELETE" });
    load();
  }

  if (loading) return <p className="text-dim text-sm">불러오는 중...</p>;

  return (
    <div>
      {user ? (
        profile?.status === "banned" ? (
          <p className="mb-8 p-4 border border-signal/40 rounded text-sm text-signal">
            경고 누적으로 글쓰기가 제한되었습니다. 관리자의 허용이 필요합니다.
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="mb-10">
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="오늘 하루, 하고 싶은 말을 남겨보세요."
              rows={3}
              className="w-full bg-panel border border-line rounded px-3 py-2 text-ink focus:border-circuit outline-none"
            />
            <div className="mt-2 flex items-center justify-between">
              <p className="text-[11px] text-dim">
                다른 사람을 비난하거나 심한 욕설이 포함되면 경고가 부여돼요. 경고 3회 시 이용이
                제한됩니다.
              </p>
              <button
                type="submit"
                disabled={posting}
                className="shrink-0 ml-4 px-4 py-2 rounded bg-circuit text-base text-sm font-display font-700"
              >
                남기기
              </button>
            </div>
            {notice && <p className="mt-2 text-xs text-signal">{notice}</p>}
          </form>
        )
      ) : (
        <p className="mb-10 p-4 border border-line rounded text-sm text-dim">
          글을 남기려면 <Link href="/login" className="text-circuit">로그인</Link>이 필요해요.
        </p>
      )}

      {posts.length === 0 ? (
        <p className="text-dim text-sm">아직 남겨진 글이 없어요.</p>
      ) : (
        <ul className="space-y-3">
          {posts.map((p) => (
            <li key={p.id} className="p-4 border border-line rounded-lg bg-panel">
              <div className="flex items-center justify-between text-xs text-dim mb-1.5">
                <span className="text-ink">{p.author_nickname}</span>
                <span>{new Date(p.created_at).toLocaleString("ko-KR")}</span>
              </div>
              <p className="text-sm text-ink whitespace-pre-wrap">{p.content}</p>
              {isAdmin && (
                <div className="mt-2 flex gap-3 text-[11px]">
                  <button
                    onClick={() => reportPost(p.id)}
                    className="text-signal hover:underline"
                  >
                    신고 처리(경고 부여)
                  </button>
                  <button
                    onClick={() => deletePost(p.id)}
                    className="text-dim hover:text-ink hover:underline"
                  >
                    삭제만
                  </button>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
