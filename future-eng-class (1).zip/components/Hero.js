"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabaseClient";
import PhotoUploadSlot from "./PhotoUploadSlot";

export default function Hero() {
  const supabase = createClient();
  const [years, setYears] = useState([]);
  const [selectedYear, setSelectedYear] = useState(null);
  const [photoUrl, setPhotoUrl] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function init() {
      const { data: yearsData } = await supabase
        .from("class_years")
        .select("year")
        .order("year", { ascending: false });
      const list = yearsData?.map((y) => y.year) || [];
      setYears(list);
      const current = list[0] ?? new Date().getFullYear();
      setSelectedYear(current);

      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", user.id)
          .single();
        setIsAdmin(profile?.role === "admin");
      }
      setLoading(false);
    }
    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedYear) return;
    async function loadPhoto() {
      const { data } = await supabase
        .from("hero_photos")
        .select("photo_url")
        .eq("year", selectedYear)
        .maybeSingle();
      setPhotoUrl(data?.photo_url ?? null);
    }
    loadPhoto();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedYear]);

  async function handleUploaded(url) {
    setPhotoUrl(url);
    await supabase
      .from("hero_photos")
      .upsert({ year: selectedYear, photo_url: url }, { onConflict: "year" });
  }

  return (
    <section className="blueprint-bg border-b border-line">
      <div className="max-w-6xl mx-auto px-6 pt-16 pb-14 grid md:grid-cols-[1fr_1.1fr] gap-10 items-center">
        <div>
          <p className="text-circuit font-display text-sm mb-3">CLASS OF FUTURE ENGINEERING</p>
          <h1 className="font-display font-700 text-4xl md:text-5xl leading-tight text-ink">
            우리가 설계하는
            <br />
            미래공학의 기록
          </h1>
          <p className="mt-5 text-dim max-w-sm">
            2005년부터 지금까지, 미래공학 반이 지나온 해마다의 순간을 모아둔 곳입니다.
          </p>

          {!loading && years.length > 0 && (
            <div className="mt-8 flex flex-wrap gap-2 max-w-md">
              {years.map((y) => (
                <button
                  key={y}
                  onClick={() => setSelectedYear(y)}
                  className={`px-3 py-1.5 text-sm rounded border transition-colors ${
                    y === selectedYear
                      ? "border-circuit text-circuit"
                      : "border-line text-dim hover:text-ink hover:border-ink"
                  }`}
                >
                  {y}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="relative">
          <div className="absolute -inset-3 border border-line rounded-lg" aria-hidden />
          <div className="relative w-full">
            {selectedYear && (
              <div className="relative aspect-[4/3] rounded-md overflow-hidden border border-line">
                <PhotoUploadSlot
                  photoUrl={photoUrl}
                  storagePath={`hero/${selectedYear}`}
                  editable={isAdmin}
                  onUploaded={handleUploaded}
                />
              </div>
            )}
            <p className="mt-3 text-right font-display text-circuit text-2xl">{selectedYear}</p>
          </div>
        </div>
      </div>
    </section>
  );
}
