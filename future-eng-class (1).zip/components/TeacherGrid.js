"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabaseClient";
import PhotoUploadSlot from "./PhotoUploadSlot";

export default function TeacherGrid({ teachers, isAdmin, onChange }) {
  const supabase = createClient();
  const [adding, setAdding] = useState(false);

  async function addSlot() {
    setAdding(true);
    await supabase.from("teachers").insert({ name: "", sort_order: teachers.length });
    onChange?.();
    setAdding(false);
  }

  async function updateName(id, name) {
    await supabase.from("teachers").update({ name }).eq("id", id);
    onChange?.();
  }

  async function updatePhoto(id, url) {
    await supabase.from("teachers").update({ photo_url: url }).eq("id", id);
    onChange?.();
  }

  async function removeTeacher(id) {
    await supabase.from("teachers").delete().eq("id", id);
    onChange?.();
  }

  return (
    <section className="py-10">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-display font-700 text-xl text-ink">선생님들</h3>
        {isAdmin && (
          <button
            onClick={addSlot}
            disabled={adding}
            className="text-xs px-3 py-1.5 border border-line rounded text-dim hover:text-circuit hover:border-circuit transition-colors"
          >
            + 선생님 추가
          </button>
        )}
      </div>

      {teachers.length === 0 ? (
        <p className="text-sm text-dim">아직 등록된 선생님이 없어요.</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-5">
          {teachers.map((t) => (
            <div key={t.id} className="text-center">
              <div className="aspect-square">
                <PhotoUploadSlot
                  photoUrl={t.photo_url}
                  storagePath={`teachers/${t.id}`}
                  editable={isAdmin}
                  shape="circle"
                  onUploaded={(url) => updatePhoto(t.id, url)}
                />
              </div>
              {isAdmin ? (
                <input
                  defaultValue={t.name}
                  placeholder="성함"
                  onBlur={(e) => updateName(t.id, e.target.value)}
                  className="mt-2 w-full bg-transparent text-center text-sm text-ink border-b border-line focus:border-circuit outline-none"
                />
              ) : (
                <p className="mt-2 text-sm text-ink">{t.name || "성함 미정"}</p>
              )}
              {isAdmin && (
                <button
                  onClick={() => removeTeacher(t.id)}
                  className="mt-1 text-[11px] text-dim hover:text-signal transition-colors"
                >
                  삭제
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
