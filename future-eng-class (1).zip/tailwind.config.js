/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        base: "#0B1220",       // 청사진 배경(딥 네이비)
        panel: "#111A2E",      // 패널 배경
        line: "#26334D",       // 격자/구분선
        ink: "#E9EDF6",        // 본문 텍스트
        dim: "#93A0BD",        // 보조 텍스트
        circuit: "#4FD1C5",    // 메인 액센트(티일)
        signal: "#FF7A45",     // 경고/신호 액센트(오렌지)
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      backgroundImage: {
        blueprint:
          "linear-gradient(rgba(79,209,197,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(79,209,197,0.06) 1px, transparent 1px)",
      },
      backgroundSize: {
        grid: "28px 28px",
      },
    },
  },
  plugins: [],
};
