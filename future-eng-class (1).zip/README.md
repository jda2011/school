# 미래공학 학급 홈페이지

Next.js(App Router) + Supabase(DB·로그인·사진 저장소) + Vercel 배포로 만든
미래공학 반 학급 홈페이지입니다.

## 담긴 기능

- **메인 화면**: 2005년부터 연도를 선택해서 대표 사진을 보여주는 히어로 영역 +
  `학급 소개 / 소식 누리집 / 하루 글` 세 개의 이동 카드
- **학급 소개**
  - 구성원 소개: 2005~2027년은 자동 생성, 2028년 이후는 관리자가 직접 "연도 창"을 추가
  - 학생마다 사진 + 이름 입력 칸, 사진 칸은 비어 있으면 "사진을 넣어주세요" 문구가 뜨고
    클릭하면 파일 선택 창이 열림
  - 선생님들 섹션: 사진 + 성함 칸 (같은 업로드 방식)
- **소식 누리집**: 공지사항 / 소식 게시판 탭, 관리자만 작성·수정·삭제 가능
- **하루 글**: 로그인한 반 구성원 누구나 작성 가능
  - 금지어(예: 시발, 개새끼, 엿먹어 등)가 포함되면 자동으로 경고 1회 부여
  - 금지어 목록은 코드가 아니라 DB에 저장되어, 관리자가 `/admin/words`에서 직접
    단어를 추가/삭제할 수 있음 (`banned_words` 테이블)
  - 관리자는 개별 글을 "신고 처리"해서 수동으로 경고를 줄 수도 있음
  - 경고 3회 누적 시 자동으로 이용 정지(`/banned`로 리다이렉트), 관리자가 대시보드에서 해제
- **관리자 신청/승인**: 로그인한 사람이 `/admin/request`에서 신청 →
  현재 관리자가 `/admin/requests`에서 "관리자 권한을 허용하시겠습니까?" 확인 후 승인/거절
  - 승인 시에만 관리자 기능이 열리고, 거절되면 지금처럼 글 작성만 가능

## 기술 스택

- Next.js 14 (App Router, JavaScript)
- Tailwind CSS
- Supabase (Postgres DB + Auth + Storage) — 로그인, 데이터 저장, 사진 업로드까지 전부 담당
- Vercel — 배포

> Vercel의 서버는 파일을 영구 저장하지 못해서(재배포마다 초기화) 사진이나 게시글을
> 그냥 서버에 저장할 수 없습니다. 그래서 무료로 쓸 수 있는 Supabase를
> DB + 로그인 + 사진 저장소로 함께 사용했습니다.

---

## 1단계. Supabase 프로젝트 만들기

1. https://supabase.com 에서 가입 후 **New Project** 생성 (무료 플랜으로 충분)
2. 프로젝트가 만들어지면 왼쪽 메뉴 **SQL Editor** 로 이동
3. 이 저장소의 `supabase/schema.sql` 파일 내용을 전체 복사해서 붙여넣고 **Run** 실행
   - 테이블, 2005~2027년 연도 자동 생성, 보안 규칙(RLS), 사진 저장 버킷까지 한 번에 만들어집니다.
4. 왼쪽 메뉴 **Settings → API** 에서 아래 3개 값을 복사해 둡니다.
   - `Project URL`
   - `anon public` 키
   - `service_role` 키 (절대 외부에 노출 금지)
5. **Authentication → Providers** 에서 Email 로그인이 켜져 있는지 확인
   (기본값으로 켜져 있습니다. 이메일 인증 확인 메일을 계속 받고 싶지 않다면
   Authentication → Settings 에서 "Confirm email"을 꺼도 됩니다.)

## 2단계. 로컬에서 값 넣고 확인하기 (선택)

1. `.env.local.example` 파일을 복사해서 `.env.local` 로 이름 바꾸기
2. Supabase에서 복사한 값 3개를 붙여넣기
3. 터미널에서:
   ```bash
   npm install
   npm run dev
   ```
4. http://localhost:3000 접속해서 확인

## 3단계. 첫 관리자(선생님/본인) 지정하기

1. 사이트에서(로컬이든 배포 후든) 먼저 **회원가입**을 한 번 합니다.
2. Supabase **SQL Editor** 에서 아래 쿼리를 본인 이메일로 바꿔 실행합니다.
   ```sql
   update profiles set role = 'admin'
   where id = (select id from auth.users where email = '본인이메일@example.com');
   ```
3. 다시 로그인하면 상단 메뉴에 **관리자** 링크가 보이고, 학급 소개/소식 누리집/하루 글
   전체에서 편집·삭제 버튼이 나타납니다.
4. 이후 다른 사람에게 관리자 권한을 줄 때는 SQL을 쓸 필요 없이,
   그 사람이 `/admin/request`에서 신청 → 내가 `/admin/requests`에서 승인하면 됩니다.

## 4단계. GitHub에 올리기

```bash
git init
git add .
git commit -m "미래공학 학급 홈페이지 초기 커밋"
git branch -M main
git remote add origin https://github.com/내계정/future-eng-class.git
git push -u origin main
```
(GitHub에서 새 저장소를 먼저 만들어 두고, 위 주소를 본인 저장소 주소로 바꿔주세요.
`.env.local`은 `.gitignore`에 들어있어서 자동으로 올라가지 않습니다 — 비밀 값이니 정상입니다.)

## 5단계. Vercel로 배포하기

1. https://vercel.com 에 GitHub 계정으로 로그인
2. **Add New → Project** → 방금 올린 GitHub 저장소 선택 → Import
3. **Environment Variables** 항목에 아래 3개를 등록 (Production/Preview/Development 모두 체크)
   | Name | Value |
   |---|---|
   | `NEXT_PUBLIC_SUPABASE_URL` | Supabase Project URL |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase anon public 키 |
   | `SUPABASE_SERVICE_ROLE_KEY` | Supabase service_role 키 |
4. **Deploy** 클릭 → 몇 분 뒤 `https://프로젝트이름.vercel.app` 주소가 발급됩니다.
5. 이후 코드를 수정해서 GitHub에 `git push`만 하면 Vercel이 자동으로 다시 배포합니다.

---

## 운영하면서 알아두면 좋은 점

- **금지어(`banned_words` 테이블)** 는 `/admin/words`에서 관리자가 자유롭게 추가/삭제할
  수 있습니다. 처음 설치 시 시발/개새끼/엿먹어 등 기본 단어가 등록되어 있고, 필요한 단어를
  계속 추가하면서 다듬으면 됩니다. "비난"처럼 맥락이 필요한 표현은 키워드만으로 완전히
  잡아내기 어려워서, 관리자가 하루 글에서 직접 "신고 처리" 버튼으로 경고를 줄 수 있게도
  만들어 두었습니다.
- 이미 `schema.sql`을 한 번 실행해서 사이트를 운영 중이라면, 전체를 다시 실행할 필요 없이
  `supabase/migration_banned_words.sql` 파일만 Supabase SQL Editor에서 실행하면
  금지어 관리 기능이 추가됩니다. (새로 만드는 프로젝트는 `schema.sql`에 이미 포함되어 있어서
  따로 실행할 필요 없어요.)
- **연도 추가**는 2028년 이후만 학급 소개 페이지에서 관리자가 직접 추가할 수 있습니다
  (2005~2027년은 이미 자동으로 만들어져 있습니다).
- **사진 용량**이 너무 큰 파일을 올리면 느릴 수 있어요. 필요하면 업로드 전 리사이즈 기능을
  추가로 붙일 수 있습니다.
- Supabase 무료 플랜은 저장 용량(1GB)과 트래픽에 제한이 있어서, 학급 규모라면
  충분하지만 사진이 아주 많아지면 유료 플랜을 고려하면 됩니다.

## 폴더 구조

```
future-eng-class/
├─ app/                     Next.js 페이지 (App Router)
│  ├─ page.js               메인 (히어로 + 3개 카드)
│  ├─ class-intro/page.js   학급 소개 (연도별 구성원 + 선생님)
│  ├─ news/page.js          소식 누리집 (공지/소식 탭)
│  ├─ daily/page.js         하루 글
│  ├─ login/page.js         로그인/회원가입
│  ├─ banned/page.js        이용 제한 안내
│  ├─ admin/page.js         관리자 대시보드 (회원/경고 관리)
│  ├─ admin/request/page.js 관리자 권한 신청
│  ├─ admin/requests/page.js 신청 승인/거절
│  └─ api/                  서버 API (하루 글 등록, 신고 처리)
├─ components/              화면 조각 컴포넌트
├─ lib/                     Supabase 클라이언트, 비속어 필터
├─ supabase/schema.sql      DB 테이블 + 보안 규칙 전체
└─ middleware.js            로그인 세션 유지 + 이용 제한 회원 접근 차단
```
