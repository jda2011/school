-- ============================================================
-- 추가 마이그레이션: 관리자가 편집 가능한 금지어 목록
-- 이미 schema.sql을 한 번 실행한 프로젝트라면, 전체를 다시 실행할 필요 없이
-- 이 파일만 Supabase SQL Editor에 붙여넣고 실행하면 됩니다.
-- (schema.sql을 아직 실행 안 한 새 프로젝트라면 schema.sql만 실행하면 되고,
--  이 파일은 이미 최신 schema.sql에 포함되어 있으니 따로 실행할 필요 없어요.)
-- ============================================================

create table if not exists banned_words (
  id bigint generated always as identity primary key,
  word text not null unique,
  created_at timestamptz not null default now()
);

insert into banned_words (word) values
  ('시발'), ('씨발'), ('ㅅㅂ'), ('병신'), ('ㅂㅅ'),
  ('개새끼'), ('새끼'), ('닥쳐'), ('죽어'), ('꺼져'),
  ('미친놈'), ('미친년'), ('지랄'), ('좆'), ('존나'),
  ('엿먹어'), ('엿 먹어'), ('fuck'), ('shit'), ('bitch')
on conflict (word) do nothing;

alter table banned_words enable row level security;

create policy "words_select_all" on banned_words for select using (true);
create policy "words_insert_admin" on banned_words for insert with check (is_admin());
create policy "words_delete_admin" on banned_words for delete using (is_admin());
