-- ============================================================
-- 미래공학 학급 홈페이지 - Supabase 스키마
-- Supabase 대시보드 > SQL Editor 에 전체 붙여넣고 실행하세요.
-- ============================================================

-- 1. 회원 프로필 (auth.users 1:1)
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text not null,
  role text not null default 'member' check (role in ('admin', 'member')),
  status text not null default 'active' check (status in ('active', 'banned')),
  warning_count int not null default 0,
  created_at timestamptz not null default now()
);

-- 회원가입 시 profiles 자동 생성
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, nickname)
  values (new.id, coalesce(new.raw_user_meta_data->>'nickname', '이름미정'));
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- 2. 학년도(연도)
create table if not exists class_years (
  id bigint generated always as identity primary key,
  year int not null unique,
  is_custom boolean not null default false,
  created_at timestamptz not null default now()
);

insert into class_years (year, is_custom)
select y, false from generate_series(2005, 2027) as y
on conflict (year) do nothing;

-- 3. 학생(구성원) - 연도별
create table if not exists members (
  id bigint generated always as identity primary key,
  year_id bigint not null references class_years(id) on delete cascade,
  name text not null default '',
  photo_url text,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

-- 4. 선생님
create table if not exists teachers (
  id bigint generated always as identity primary key,
  name text not null default '',
  photo_url text,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

-- 5. 메인 화면 연도별 대표 사진
create table if not exists hero_photos (
  id bigint generated always as identity primary key,
  year int not null unique,
  photo_url text,
  updated_at timestamptz not null default now()
);

-- 6. 공지사항
create table if not exists notices (
  id bigint generated always as identity primary key,
  title text not null,
  content text not null,
  created_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 7. 소식 게시판
create table if not exists news_posts (
  id bigint generated always as identity primary key,
  title text not null,
  content text not null,
  created_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 8. 하루 글
create table if not exists daily_posts (
  id bigint generated always as identity primary key,
  author_id uuid references profiles(id),
  author_nickname text not null,
  content text not null,
  is_flagged boolean not null default false,
  flag_reason text,
  created_at timestamptz not null default now()
);

-- 9. 관리자 권한 신청
create table if not exists admin_requests (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  message text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamptz not null default now(),
  decided_at timestamptz
);

-- 10. 금지어(비속어) 목록 - 관리자가 화면에서 추가/삭제
create table if not exists banned_words (
  id bigint generated always as identity primary key,
  word text not null unique,
  created_at timestamptz not null default now()
);

insert into banned_words (word) values
  ('시발'), ('씨발'), ('ㅅㅂ'), ('병신'), ('ㅂㅅ'),
  ('개새끼'), ('새끼'), ('닥쳐'), ('죽어'), ('꺼져'),
  ('미친놈'), ('미친년'), ('지랄'), ('좆'), ('존나'),
  ('엿먹어'), ('엿 먹어'), ('fuck'), ('shit'), ('bitch')
on conflict (word) do nothing;

-- ============================================================
-- RLS (Row Level Security)
-- ============================================================
alter table profiles enable row level security;
alter table class_years enable row level security;
alter table members enable row level security;
alter table teachers enable row level security;
alter table hero_photos enable row level security;
alter table notices enable row level security;
alter table news_posts enable row level security;
alter table daily_posts enable row level security;
alter table admin_requests enable row level security;
alter table banned_words enable row level security;

-- 헬퍼: 현재 로그인 유저가 admin 인지
create or replace function is_admin()
returns boolean as $$
  select exists (
    select 1 from profiles where id = auth.uid() and role = 'admin'
  );
$$ language sql stable security definer;

-- profiles: 로그인 유저는 전체 조회 가능(이름 표시용), 본인 것만 수정 가능, 관리자는 전체 수정 가능
create policy "profiles_select_all" on profiles for select using (true);
create policy "profiles_update_self" on profiles for update using (auth.uid() = id);
create policy "profiles_update_admin" on profiles for update using (is_admin());

-- class_years / members / teachers / hero_photos: 누구나 조회, 관리자만 쓰기
create policy "years_select_all" on class_years for select using (true);
create policy "years_write_admin" on class_years for insert with check (is_admin());
create policy "years_update_admin" on class_years for update using (is_admin());
create policy "years_delete_admin" on class_years for delete using (is_admin());

create policy "members_select_all" on members for select using (true);
create policy "members_write_admin" on members for insert with check (is_admin());
create policy "members_update_admin" on members for update using (is_admin());
create policy "members_delete_admin" on members for delete using (is_admin());

create policy "teachers_select_all" on teachers for select using (true);
create policy "teachers_write_admin" on teachers for insert with check (is_admin());
create policy "teachers_update_admin" on teachers for update using (is_admin());
create policy "teachers_delete_admin" on teachers for delete using (is_admin());

create policy "hero_select_all" on hero_photos for select using (true);
create policy "hero_write_admin" on hero_photos for insert with check (is_admin());
create policy "hero_update_admin" on hero_photos for update using (is_admin());

-- notices / news_posts: 누구나 조회, 관리자만 작성/수정/삭제
create policy "notices_select_all" on notices for select using (true);
create policy "notices_write_admin" on notices for insert with check (is_admin());
create policy "notices_update_admin" on notices for update using (is_admin());
create policy "notices_delete_admin" on notices for delete using (is_admin());

create policy "news_select_all" on news_posts for select using (true);
create policy "news_write_admin" on news_posts for insert with check (is_admin());
create policy "news_update_admin" on news_posts for update using (is_admin());
create policy "news_delete_admin" on news_posts for delete using (is_admin());

-- daily_posts: 로그인 + 정지 아닌 유저만 작성, 본인 글은 본인이 삭제 가능, 관리자는 전체 관리
create policy "daily_select_all" on daily_posts for select using (true);
create policy "daily_insert_active_member" on daily_posts for insert
  with check (
    auth.uid() = author_id
    and exists (select 1 from profiles where id = auth.uid() and status = 'active')
  );
create policy "daily_delete_self_or_admin" on daily_posts for delete
  using (auth.uid() = author_id or is_admin());
create policy "daily_update_admin" on daily_posts for update using (is_admin());

-- admin_requests: 본인 신청 조회/생성, 관리자는 전체 조회/수정
create policy "req_select_self_or_admin" on admin_requests for select
  using (auth.uid() = user_id or is_admin());
create policy "req_insert_self" on admin_requests for insert
  with check (auth.uid() = user_id);
create policy "req_update_admin" on admin_requests for update using (is_admin());

-- banned_words: 누구나 조회 가능(필터링에 필요), 관리자만 추가/삭제
create policy "words_select_all" on banned_words for select using (true);
create policy "words_insert_admin" on banned_words for insert with check (is_admin());
create policy "words_delete_admin" on banned_words for delete using (is_admin());

-- ============================================================
-- Storage: 사진 업로드용 버킷 (photos) - 최초 1회
-- Supabase 대시보드 > Storage 에서도 만들 수 있지만 SQL로도 생성 가능
-- ============================================================
insert into storage.buckets (id, name, public)
values ('photos', 'photos', true)
on conflict (id) do nothing;

create policy "photos_public_read" on storage.objects for select
  using (bucket_id = 'photos');
create policy "photos_admin_write" on storage.objects for insert
  with check (bucket_id = 'photos' and is_admin());
create policy "photos_admin_update" on storage.objects for update
  using (bucket_id = 'photos' and is_admin());
create policy "photos_admin_delete" on storage.objects for delete
  using (bucket_id = 'photos' and is_admin());

-- ============================================================
-- 맨 처음 관리자(사이트 소유자) 지정 방법
-- 1) 사이트에서 일반 회원가입을 먼저 진행
-- 2) 아래 쿼리의 이메일을 본인 이메일로 바꿔 SQL Editor에서 실행
-- ============================================================
-- update profiles set role = 'admin'
-- where id = (select id from auth.users where email = 'YOUR_EMAIL@example.com');
